# Changelog

All notable changes to `ignition-contracts` will be documented in this file

## 1.0.0 - 2019-08-30

- initial release
