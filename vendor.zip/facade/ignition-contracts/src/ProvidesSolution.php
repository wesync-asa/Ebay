<?php

namespace Facade\IgnitionContracts;

interface ProvidesSolution
{
    public function getSolution(): Solution;
}
